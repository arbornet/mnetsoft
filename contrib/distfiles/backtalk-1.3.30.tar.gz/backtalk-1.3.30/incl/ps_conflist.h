/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void cache_conflist(int load);
char *cfpath(char *name);
#ifdef CLEANUP
void free_clist(void);
#endif
