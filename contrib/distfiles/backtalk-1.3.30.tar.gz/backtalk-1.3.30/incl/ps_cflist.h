void func_push_cflist(void);
char *nth_conf(int n);
void func_cflist_array(void);
