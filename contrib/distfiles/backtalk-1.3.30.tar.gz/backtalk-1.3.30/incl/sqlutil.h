/* (c) 2001, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void make_sql_connection(void);
