/* Copyright 2003, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

#ifdef PART_DIR
char *bbspartpath(char *path, char *id, char *name);
void mkpartdir(char *name);
#endif /* PART_DIR */
