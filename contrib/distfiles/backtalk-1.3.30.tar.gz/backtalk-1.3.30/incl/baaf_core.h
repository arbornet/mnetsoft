/* Copyright 2003, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

char *baaf_path(char *fname);
void del_attach(char *hand);
