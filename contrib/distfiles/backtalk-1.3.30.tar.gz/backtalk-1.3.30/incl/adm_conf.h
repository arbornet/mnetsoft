/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

char *check_conf(char *name, char *loc, char *pfile);
void add_conflist(char *alias, char *dir);
void make_confdir(char *dir, char *pfile, char *fw, int mode, char *title);
char *make_part_name(char *conf);
