/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

char *read_file(char *fname, int lock);
