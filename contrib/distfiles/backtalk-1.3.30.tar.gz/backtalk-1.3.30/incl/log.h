/* (c) 2003, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void macro_log(char *filename, char *macroname, int nstack, int create);
