/* Copyright 2001, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

extern char *cf_email_fromaddr;
extern char *cf_email_fromname;
extern char *cf_email_organization;
extern char *cf_sql_hostname;
extern char *cf_sql_port;
extern char *cf_sql_login;
extern char *cf_sql_password;
extern char *cf_sql_dbname;

void read_config_file(void);
