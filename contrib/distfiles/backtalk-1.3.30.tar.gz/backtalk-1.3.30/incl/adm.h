/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

#if __STDC__
void die(const char *, ...);
#else
void die();
#endif /* __STDC__ */
void set_httpd();
void set_cfadm();
