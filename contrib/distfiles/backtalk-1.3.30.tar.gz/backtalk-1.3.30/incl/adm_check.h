/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

int login_bad(char *lid, char *msg);
char *current_passwd(char *lid);
