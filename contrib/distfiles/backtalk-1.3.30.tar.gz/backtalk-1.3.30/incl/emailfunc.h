/* Copyright 2003, Jan D. Wolter, All Rights Reserved. */

void func_email_new(void);
void func_email_body(void);
void func_email_recip(void);
void func_email_send(void);
void func_email_close(void);
