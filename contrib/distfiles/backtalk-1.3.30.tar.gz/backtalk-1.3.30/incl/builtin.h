/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void func_rand(void);
void func_srand(void);
void func_time(void);
void func_ctime(void);
void func_ztime(void);
void func_dtime(void);
void func_htime(void);
void func_itime(void);
void func_timeout(void);
void func_sleep(void);
void func_chomp(void);
void func_substr(void);
void func_inlist(void);
void func_parse(void);
void func_split(void);
void func_clip(void);
void func_version(void);
void func_cvn(void);
void func_cgiquote(void);
void func_jsquote(void);
void func_cap(void);
void func_caps(void);
void func_showopt(void);
