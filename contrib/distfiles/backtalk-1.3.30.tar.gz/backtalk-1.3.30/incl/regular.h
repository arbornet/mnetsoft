void func_regex(void);
void func_grep(void);
void func_ogrep(void);
void func_sgrep(void);
int rgrep_step(Regex *reg, char *str, int *i, int nmatch);
void func_rgrep(void);
