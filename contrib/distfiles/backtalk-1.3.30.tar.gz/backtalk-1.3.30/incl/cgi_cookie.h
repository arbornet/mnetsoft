/* Copyright 1998, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

char *get_cookie(char *name);
