/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void func_add(void);
void func_sub(void);
void func_mul(void);
void func_div(void);
void func_mod(void);
void func_and(void);
void func_or(void);
void func_not(void);
void func_band(void);
void func_bor(void);
void func_bnot(void);
void func_neg(void);
void func_abs(void);
void func_eq(void);
void func_ne(void);
void func_gt(void);
void func_lt(void);
void func_ge(void);
void func_le(void);
void func_cvi(void);
void func_cvt(void);
void func_cvs(void);
void func_cvp(void);
void func_cvscol(void);
