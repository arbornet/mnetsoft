/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

int conf_access(char *conf);
