/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void func_get(void);
void func_put(void);
void func_length(void);
