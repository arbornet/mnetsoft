/* Copyright 2003, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void func_mimename(void);
