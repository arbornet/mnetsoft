/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void func_aload(void);
void func_in(void);
void func_asort(void);
