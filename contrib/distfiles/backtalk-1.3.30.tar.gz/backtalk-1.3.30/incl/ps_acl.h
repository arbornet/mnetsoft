/* Copyright 2003, Jan D. Wolter, All Rights Reserved. */

int read_acl(char *dir, int *mayread, int *mayresp, int *maypost);
