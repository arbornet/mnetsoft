#include <sys/types.h>
#include <time.h>

time_t tm2sec(const struct tm *t);
