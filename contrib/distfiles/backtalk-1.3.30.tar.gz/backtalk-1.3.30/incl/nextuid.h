/* (c) 1996-2001, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

char *showopt_nextuid_module;
uid_t next_uid(int inc);
