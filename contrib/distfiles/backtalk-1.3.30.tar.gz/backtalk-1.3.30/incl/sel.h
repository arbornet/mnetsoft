/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void rev_sel(char *);
void func_rev_sel(void);
void func_count_sel(void);
int next_int(int last_item);
void func_next_int(void);
int in_sel(int i, char *sel);
void func_in_sel(void);
