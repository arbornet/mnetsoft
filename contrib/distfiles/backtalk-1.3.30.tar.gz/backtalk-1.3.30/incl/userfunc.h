/* (c) 1996-2001, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void func_userinfo(void);
void func_useremail(void);
void func_firstuser(void);
void func_nextuser(void);
void func_seekuser(void);

void func_groupname(void);
void func_groupid(void);
void func_ingroup(void);
void func_groups(void);
void func_dfltgroup(void);

void func_newgroup(void);
void func_newgroupmem(void);
void func_delgroup(void);
void func_delgroupmem(void);
