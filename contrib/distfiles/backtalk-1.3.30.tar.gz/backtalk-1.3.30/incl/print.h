/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void print_value(FILE *fp, Token *t);
