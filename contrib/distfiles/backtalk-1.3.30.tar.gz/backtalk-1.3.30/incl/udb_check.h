/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

int fullname_bad(char *val, char *msg);
int passwd_bad(char *pw, char *lid, char *msg);
