void func_newuser(void);
void func_selectuser(void);
void func_changename(void);
void func_changeemail(void);
void func_changepass(void);
void func_changegroup(void);
void func_removeuser(void);
void func_validate(void);
