/* This is a place to put local configuration settings that override what is
 * set by config.h, and which we don't want overwritten everytime we run
 * configure.
 */
