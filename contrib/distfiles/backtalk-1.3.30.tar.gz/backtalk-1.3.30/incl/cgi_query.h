/* Copyright 1996, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

char *get_query(int saverep);
void load_query(char *query);
