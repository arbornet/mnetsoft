/* Copyright 2002, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

void free_val(Token *t);
void free_array(Array *a);
void free_regex(Regex *r);
void free_dict(HashTable *h);
