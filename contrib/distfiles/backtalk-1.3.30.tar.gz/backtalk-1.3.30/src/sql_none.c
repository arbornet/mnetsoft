/* Copyright 2001, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

/* SQL Server Interface - No SQL server version */

char *showopt_sql_module= "none";
