#include <stdio.h>
#include "version.h"

main() {printf("%d.%d.%d\n",VERSION_A,VERSION_B,VERSION_C);}
