/* Copyright 2001, Jan D. Wolter and Steven R. Weiss, All Rights Reserved. */

char *showopt_session_module= "none";
